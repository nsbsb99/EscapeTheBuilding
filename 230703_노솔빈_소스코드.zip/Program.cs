﻿using EscapeBuilding.EscapeBuilding;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace EscapeBuilding
{   
    public class Program
    {
        public static int clearNumber = 0;
        static void Main(string[] args)
        {
            Title title = new Title();
            title.EscapeTheBuilding();

        }
    }
}


